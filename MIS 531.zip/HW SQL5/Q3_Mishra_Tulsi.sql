SET ServerOutput On;
CREATE OR REPLACE PROCEDURE CURR_BALANCE
  AS

-- Cursor to get the customer id from customers table
CURSOR CUST_CURSOR IS
SELECT CUST_ID 
FROM CUSTOMERS;

-- Cursor to get the things from purchases
-- Passing the customer id from previous customer table into this cursor
CURSOR PUR_CURSOR(in_cust_id varchar2) IS
Select PURCHASE_ID, CUST_ID, PURCHASE_AMOUNT, PENDING_FLAG
FROM PURCHASES
where CUST_ID =in_cust_id;

-- Cursor to get the attributes from Purchases table
CURSOR CURSOR1 IS
Select PURCHASE_ID, CUST_ID, PURCHASE_AMOUNT, PENDING_FLAG
FROM PURCHASES
WHERE PENDING_FLAG=1;

purid PURCHASES.PURCHASE_ID%type;
custid PURCHASES.CUST_ID%type;
puramt PURCHASES.PURCHASE_AMOUNT%type;
pendflag PURCHASES.PENDING_FLAG%type;
custCreditLimit CUSTOMERS.CREDIT_LINE%type;
PAYMENTBALANCE CUSTOMERS.CURR_BALANCE%type := 0;
custcurrbalance CUSTOMERS.CURR_BALANCE%type;
purchase_amt PURCHASES.PURCHASE_AMOUNT%type;
flag number(2):=0;
pf number(2);

BEGIN
-- The loop is nested and cust_cursor helps to get the customer id from Customers table
OPEN CUST_CURSOR;
    LOOP
        FETCH cust_cursor into custid;
        EXIT WHEN cust_cursor%notfound;
        flag :=0;
-- The below cursor helps to get the other attributes from Purchases for the same customer id
--The customer id is passed into the below cursor so that we retrieve the pending flag for the customer
--we increment pf when we encounter 1 in the pending flag of any of the purchases for that customer id
--It is done for every customer in the customer table
--The variable is then checked 
--if it has a value other than 0, then the customer has pending purchases
--otherwise print no pending purchases
            OPEN pur_cursor(custid);
            LOOP
            FETCH  pur_cursor into purid, custid, puramt,pendflag;
            EXIT WHEN pur_cursor%notfound;
            pf := TO_NUMBER(pendflag,'9');
                if pf=1
                    THEN
                    flag :=flag+1;
                    End if;
            END LOOP;
            CLOSE pur_cursor;
        if flag=0
        THEN dbms_output.put_line('No pending purchases for customer '||custid);
        END if;
    END LOOP;

-- The below loop helps to carry out the rest of the requirements
--This is run on the purchases table and uses pend flag of the purchases to evaluate
-- The credit limit is derived from the customer table
--It is then compared with the balance for the customer
-- payment balance, pur amtg for the purchase amount and cust curr balance to store the new values aare used for teh operation
OPEN cursor1;
LOOP
    FETCH  cursor1 into purid, custid, puramt,pendflag;
    EXIT WHEN cursor1%notfound;
    
    SELECT CURR_BALANCE, CREDIT_LINE  into custcurrbalance, custCreditLimit 
    FROM CUSTOMERS
    where CUST_ID = custid;
    
    if pendflag =1
    THEN
         if custcurrbalance >= custCreditLimit 
            Then
            paymentBalance :=paymentBalance + puramt;
            dbms_output.put_line('One or more purchases were not processed for customer'||' '||custid);
         ELSIf (custcurrbalance < custCreditLimit)
         THEN
          paymentBalance :=paymentBalance + puramt;
          custcurrbalance := custcurrbalance+puramt;
          UPDATE CUSTOMERS
          SET CUSTOMERS.CURR_BALANCE = custcurrbalance
          where CUST_ID =custid;
          UPDATE PURCHASES
          SET PURCHASES.PENDING_FLAG =0
          where CUST_ID=custid;
             if custcurrbalance >= custCreditLimit
                Then
                paymentBalance :=paymentBalance + puramt;
                dbms_output.put_line('One or more purchases were not processed for customer'||' '||custid);
             END if;
         END if;
    
    END if;
    
END LOOP;

END;
/
     
EXECUTE CURR_BALANCE;



 


    