Set ServerOutput on;

-- Sequence for customerID
CREATE SEQUENCE customerID_seq
MINVALUE 10001
MAXVALUE 99999
START WITH 10001
INCREMENT BY 1
CACHE 10001;

--Trigger to implement customer ID sequence 
-- Trigger automatically takes the next sequence number irrespective of what the cust id is updated
CREATE OR REPLACE TRIGGER customers_id
    BEFORE
        INSERT
        OR
        UPDATE OF CUST_ID
    ON CUSTOMERS
    FOR EACH ROW
    
DECLARE 
    custid CUSTOMERS.CUST_ID%type;
    
Begin
     custid :=CONCAT('C',customerid_seq.nextval);
     :new.CUST_ID := custid;
END;
/
     
    
--Sequence for purchase ID
CREATE SEQUENCE purchase_id_seq
MINVALUE 100001
MAXVALUE 999999
START WITH 100001
INCREMENT BY 1
CACHE 100001;   
    

--Trigger to implement purchase ID sequence 
CREATE OR REPLACE TRIGGER purid_seq
    BEFORE
        INSERT
        OR
        UPDATE OF PURCHASE_ID
    ON PURCHASES
    FOR EACH ROW
    
DECLARE 
    pursid PURCHASES.PURCHASE_ID%type;
    
Begin
     pursid :=CONCAT('P',purchase_id_seq.nextval);
     :new.PURCHASE_ID := pursid;
END;
/   

