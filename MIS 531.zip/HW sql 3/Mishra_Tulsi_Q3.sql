/* By submitting this assignment for grading, I state or affirm that the work submitted is my own work and 
I did not receive assistance nor provide assistance from another student (or external agent). */ 
/* In the below select function,only the customer code and customerf name are displayed directly from the 
customer table and the rest of the columns are displayed from tables from inline select. Four inline selects
have been used to display number of chartered flights, total distance covered, total charter cost and aircraft number*/
Select c.Cus_Code as "Customer Code",
       CUS_FNAME||' '||CUS_LNAME as "Customer Name",
       to_char(CUS_BALANCE, '$9,999,999.99') as "Customer Credit(USD)",
       s1.nct as "Number of Chartered Trips",
       s2.tdc as "Total Distance Covered",
       s3.tcc as "Total Charter Cost",
       s4.a as "Aircraft Number"
From 
avia.Customer c,
-- Below inline select helps to get the number of chartered flights by joining the customer and charter tables
(Select cu.CUS_CODE, count(ch.Char_trip)as nct
    from AVIA.customer cu, AVIA.CHARTER ch
    where cu.cus_code= ch.cus_code
    group by cu.Cus_Code) s1,
/*Below inline select helps to get the total diatnce covered and grouped by customer id. The coalesce 
function helps to get the null disatnce covered to change. The piping lines help to append miles to the total distance.*/
(Select cu.cus_code, Coalesce(sum(ch.CHAR_DISTANCE),0)||' Miles' as tdc
    from Avia.Customer cu, Avia.charter ch
    where cu.cus_code= ch.cus_code
-- this filter helps to filter the customers who have travelled more than  1000 miles  
    And ch.Char_distance>=1000
    group by cu.Cus_Code) s2,
/*Below inline select helps to get the total charter cost. 
The to_char function and format metioned helps to return the total charter cost in the required format.*/ 
(Select ch.cus_code,to_char(sum((ch.CHAR_DISTANCE)*MOD_CHG_MILE),'$9,999,999.99') as tcc
    from avia.charter ch, avia.model m, avia.aircraft a
    where m.mod_code=a.mod_code and a.ac_number= ch.ac_number
    group by ch.cus_code
    ) s3,
/* Below inline select helps to get the aircrafts number in which the repsctive customers have 
travelled. The listagg function has been used to this effect.*/
(Select cus_code, Listagg (AC_Number,',') within group (order by ac_number) as a
    from (select distinct(ac_number), cus_code from avia.charter)
    group by cus_code) s4
-- where used to join tables created with customer table
Where
     c.cus_code=s1.cus_code
     And s1.cus_code=s2.cus_code
     And s2.cus_code=s3.cus_code
     And s3.cus_code=s4.cus_code
     and c.cus_balance>0
 Group by c.Cus_Code, CUS_FNAME||' '||CUS_LNAME, to_char(CUS_BALANCE, '$9,999,999.99'), s1.nct, s2.tdc, s3.tcc, s4.a
 ;    