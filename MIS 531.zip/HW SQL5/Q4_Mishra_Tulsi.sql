SET ServerOutput  On;

--Passing custoer id, high percentage and low percentage
CREATE OR REPLACE PROCEDURE UPDATE_TIER
(CUSTSID CUSTOMERS.CUST_ID%type,
lowper varchar2,
highper varchar2)
AS

custid CUSTOMERS.CUST_ID%type;
stdt STATEMENTS.ST_DATE%type;
stdt1 varchar(8);
sysdt varchar(8);
dudt STATEMENTS.DUE_DATE%type; 
strtblnc STATEMENTS.STARTING_BALANCE%type;
pur STATEMENTS.PURCHASES%type;
chg STATEMENTS.CHARGES%type;
tchg STATEMENTS.CHARGES%type;
oldtier CUSTOMERS.TIER_ID%type;
newtier CUSTOMERS.TIER_ID%type;
oldtiername varchar(8);
tiername varchar(8);
custFname CUSTOMERS.FIRST_NAME%type;
custLname CUSTOMERS.LAST_NAME%type;
crdtLmt CUSTOMERS.CREDIT_LINE%type;
tmonthpur STATEMENTS.PURCHASES%type;
avgmonthpur STATEMENTS.PURCHASES%type;

BEGIN

custid := CUSTSID;
-- Running application errors and custome messages for the percentage value validation
if highper <lowper
Then 
raise_application_error (-200010, 'High percenetage cannot be less than low percentage.');
DBMS_OUTPUT.PUT_LINE('Please check your high percentage and low percentage values');
END IF;
if (highper<0.1 and highper >0.9)
THEN
raise_application_error (-20011, 'Highper value out of bounds');
DBMS_OUTPUT.PUT_LINE('Please enter a correct value for highper');
END if;
if (lowper<0.1 and lowper >0.9)
THEN
raise_application_error (-20011, 'Lowper value out of bounds');
DBMS_OUTPUT.PUT_LINE('Please enter a correct value for lowper');
END if;

-- Figuring out the old tier of the cutomer and saving them to oldtiername
Select FIRST_NAME,LAST_NAME into custFname, custLname
    FROM CUSTOMERS
    where CUST_ID = custid;
        
        Select TIER_ID into oldtier
			FROM CUSTOMERS
			WHERE CUST_ID =custid;
		
			if oldtier=1
			THEN oldtiername :='Bronze';
			END if;
			
			if oldtier=2
			THEN oldtiername :='Silver';
			END if;
			
			if oldtier=3
			THEN oldtiername :='Gold';
			END if;
	
    -- Credit limit determined for customer from Customers table
		Select CREDIT_LINE into crdtLmt
			FROM CUSTOMERS
			WHERE CUST_ID =custid;
		
    --Getting the average purchases for past three months	
        tmonthpur :=0;
        avgmonthpur := 0;
		FOR i in 1..3 LOOP 
            SELECT PURCHASES into pur
            FROM STATEMENTS
            where CUST_ID = custid
            AND to_char(trunc(ST_DATE), 'MON')= to_char(add_months(SYSDATE,-i), 'MON');
        tmonthpur := tmonthpur+pur;
        END LOOP;
        avgmonthpur := tmonthpur/3;
    
    -- Getting the pending charges for the past three months    
        tchg:=0;
		FOR i in 1..3 LOOP
        SELECT CHARGES into chg
            FROM STATEMENTS
            where CUST_ID=custid
            AND to_char(trunc(ST_DATE), 'MON')= to_char(add_months(SYSDATE,-i), 'MON');
         
        tchg := tchg + chg;
        END LOOP;
	
    --Determining the new tier of the customer and saving it to new tiername
    --comparing the new tier to old tier and running as per requirement
    --setting the customer tier to new value in case of changes
    --printing out no change in the required format if no changes are made
		if(tchg>0 OR (avgmonthpur< (lowper*crdtLmt)))
		THEN newtier := 1;
			 tiername := 'Bronze';
			 if (newtier=oldtier)
			 THEN 
			 dbms_output.put_line(custFname||' '||custLname||'-'||'No Change');
			 ELSE
             Update CUSTOMERS
             SET TIER_ID = newtier
             where CUST_ID =custid;
			 dbms_output.put_line(custFname||' '||custLname||'-'||'Reward tier changed from '||oldtiername||'to '||tiername);
			 END IF;
		END if;
		
		if((avgmonthpur> (lowper*crdtLmt)) AND(avgmonthpur< (highper*crdtLmt)))
		THEN newtier := 2;
			 tiername := 'Silver';
			 if (newtier=oldtier)
			 THEN 
			 dbms_output.put_line(custFname||' '||custLname||'-'||'No Change');
			 ELSE
             Update CUSTOMERS
             SET TIER_ID = newtier
             where CUST_ID =custid;
			 dbms_output.put_line(custFname||' '||custLname||'-'||'Reward tier changed from '||oldtiername||'to '||tiername);
			 END IF;
		END if;
		
		if((avgmonthpur> (highper*crdtLmt)))
		THEN newtier := 3;
			 tiername := 'Gold';
			 if (newtier=oldtier)
			 THEN 
			 dbms_output.put_line(custFname||' '||custLname||'-'||'No Change');
			 ELSE
             Update CUSTOMERS
             SET TIER_ID = newtier
             where CUST_ID =custid;
			 dbms_output.put_line(custFname||' '||custLname||'-'||'Reward tier changed from '||oldtiername||'to '||tiername);
			 END IF;
		END if;
  
END;
/

