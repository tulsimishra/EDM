Set ServerOutput On;

-- Initiating trigger for update of pending flag 
CREATE OR REPLACE TRIGGER Reward_Trig
    BEFORE
    UPDATE OF PENDING_FLAG
    ON PURCHASES
    FOR EACH ROW
    
Declare
 reward_points number (4);
 purchaseAmt number(4);
 pursID varchar(8);
 custid varchar(8);
 defaultRewards number(4);
 tierid varchar(2);
 extraPoints number(3,2);
 extraReward number(4);
 oldReward number(4);
 totalReward number (4);
 newReward number(4);
 
 
    
Begin

    pursid := :new.PURCHASE_ID;
    
    purchaseAmt := :new.PURCHASE_AMOUNT;
    
    custid := :new.CUST_ID;
  -- calculating deafault rewards for the purchase amount      
    defaultRewards := purchaseAmt*1.5;
    
    Select tier_id Into tierID
    from CUSTOMERS
    where CUST_ID = custid;
    
    Select EARNED_POINTS into oldReward
    from CUSTOMERS 
    where CUST_ID = custid;
    
 -- to get the extra point percentage for calculating the extra points
    Select EXTRA_POINTS into extraPoints 
    from REWARDS_TIER
    where TIER_ID = tierid;
   
 -- caluclating extra points 
    extraReward := extraPoints * purchaseAmt;
 -- total rewards by summing up default rewards with extra rewards
    totalReward := defaultRewards + extraReward;
 -- adding the total new rewards to old reward to calculate the new reward
    newReward := oldReward + totalReward;
  
 -- to update the new reward points into customer's earned points  
    Update CUSTOMERS 
    SET CUSTOMERS.EARNED_POINTS = newReward
    Where CUST_ID =custid;

END;
/
    

    


