/* By submitting this assignment for grading, I state or affirm that the work submitted is my own work 
and I did not receive assistance nor provide assistance from another student (or external agent). */ 
/* The below query combines the customer data with the employee data by the union function.
The journey count is derived from the charter table and hence it has been joined with both customers and 
employees.*/
/*We have used left outer join to include all data from customer table and employee table*/
Select *
From
   (Select 'Customer'as Type,
    cus.CUS_CODE as "Code",
    CUS_FNAME as "First Name",
    CUS_INITIAL as "Initial",
    CUS_LNAME as "Last Name", 
    count(distinct(ch.CHAR_TRIP)) as"Journey Count"
    from AVIA.Customer cus left outer join AVIA.CHARTER ch
    on cus.CUS_CODE=ch.CUS_CODE 
    group by 'Customer', cus.CUS_CODE, CUS_FNAME, CUS_INITIAL, CUS_LNAME
 /* The below union function helps combine the customer data with the respective data from
 the employee.*/
    union 
    select 'Employee',emp.EMP_NUM,EMP_FNAME,EMP_INITIAL,EMP_LNAME,count(distinct(c.CHAR_TRIP))
    from Avia.EMPLOYEE emp  left outer join AVIA.crew c
    on emp.EMP_NUM =c.EMP_NUM
    group by 'Employee', emp.EMP_NUM, EMP_FNAME, EMP_INITIAL, EMP_LNAME)s 
-- order by helps to sort the results by last name
order by "Last Name" 
;

--Question 2
/* By submitting this assignment for grading, I state or affirm that the work submitted is my own work and 
I did not receive assistance nor provide assistance from another student (or external agent). */ 
Select e.EMP_NUM as "Employee Num", 
--Piping lines helps to concantante three fields into one, viz. the employee name
       EMP_TITLE||EMP_FNAME||' '||EMP_LNAME as "Employee Name",
-- to replace null values with "N/A", coalesece has been used in the below query line
       Coalesce(c.CREW_JOB,'N/A') as "Crew Job", 
       count(c.CREW_JOB) as "Num Times Served",
       count(distinct(c.CHAR_TRIP)) as "Num Charters with Job"
/*Below left outer join helps us to display 
all employees from employee table irrespective of them being a part of the crew*/
From AVIA.EMPLOYEE e left outer join AVIA.CREW c
on e.EMP_NUM =c.EMP_NUM
-- below query helps to filter results for employees hired on or after 2002
Where EMP_HIRE_DATE >= '01-Jan-2002' 
group by e.EMP_NUM, Coalesce(c.CREW_JOB,'N/A'), EMP_TITLE||EMP_FNAME||' '||EMP_LNAME, c.CREW_JOB
-- below query line helps to filter the results first by Employee Name and then by Crew Job
order by e.EMP_NUM, c.CREW_JOB
;

--Question 3
/* By submitting this assignment for grading, I state or affirm that the work submitted is my own work and 
I did not receive assistance nor provide assistance from another student (or external agent). */ 
/* In the below select function,only the customer code and customerf name are displayed directly from the 
customer table and the rest of the columns are displayed from tables from inline select. Four inline selects
have been used to display number of chartered flights, total distance covered, total charter cost and aircraft number*/
Select c.Cus_Code as "Customer Code",
       CUS_FNAME||' '||CUS_LNAME as "Customer Name",
       to_char(CUS_BALANCE, '$9,999,999.99') as "Customer Credit(USD)",
       s1.nct as "Number of Chartered Trips",
       s2.tdc as "Total Distance Covered",
       s3.tcc as "Total Charter Cost",
       s4.a as "Aircraft Number"
From 
avia.Customer c,
-- Below inline select helps to get the number of chartered flights by joining the customer and charter tables
(Select cu.CUS_CODE, count(ch.Char_trip)as nct
    from AVIA.customer cu, AVIA.CHARTER ch
    where cu.cus_code= ch.cus_code
    group by cu.Cus_Code) s1,
/*Below inline select helps to get the total diatnce covered and grouped by customer id. The coalesce 
function helps to get the null disatnce covered to change. The piping lines help to append miles to the total distance.*/
(Select cu.cus_code, Coalesce(sum(ch.CHAR_DISTANCE),0)||' Miles' as tdc
    from Avia.Customer cu, Avia.charter ch
    where cu.cus_code= ch.cus_code
-- this filter helps to filter the customers who have travelled more than  1000 miles  
    And ch.Char_distance>=1000
    group by cu.Cus_Code) s2,
/*Below inline select helps to get the total charter cost. 
The to_char function and format metioned helps to return the total charter cost in the required format.*/ 
(Select ch.cus_code,to_char(sum((ch.CHAR_DISTANCE)*MOD_CHG_MILE),'$9,999,999.99') as tcc
    from avia.charter ch, avia.model m, avia.aircraft a
    where m.mod_code=a.mod_code and a.ac_number= ch.ac_number
    group by ch.cus_code
    ) s3,
/* Below inline select helps to get the aircrafts number in which the repsctive customers have 
travelled. The listagg function has been used to this effect.*/
(Select cus_code, Listagg (AC_Number,',') within group (order by ac_number) as a
    from (select distinct(ac_number), cus_code from avia.charter)
    group by cus_code) s4
-- where used to join tables created with customer table
Where
     c.cus_code=s1.cus_code
     And s1.cus_code=s2.cus_code
     And s2.cus_code=s3.cus_code
     And s3.cus_code=s4.cus_code
     and c.cus_balance>0
 Group by c.Cus_Code, CUS_FNAME||' '||CUS_LNAME, to_char(CUS_BALANCE, '$9,999,999.99'), s1.nct, s2.tdc, s3.tcc, s4.a
 ;    
 
--Question 4
/* By submitting this assignment for grading, I state or affirm that the work submitted is my own work and 
I did not receive assistance nor provide assistance from another student (or external agent). */ 
/* To achieve the solution in this question we have joined two major inline selects with in the main select. 
The purpose of the first inline select is to get the manufacturer name, number of models, toatl hours flown,
manufacturer type, Top destination in term of hours. The sceond inline select is to get the corresponding 
ranking of the manufacturer in terms of number of times that the aircrafts from the particular manufacturer 
has flown to.*/
select distinct q1.*,
    coalesce(s2.ranking,0)as "Trip Rank" from 
(
select m.mod_manufacturer as "Manufacturer Name",
       count(distinct(m.mod_code)) as "Num of Models",
-- Coalesce to convert the null values, i.e the manufactuere who havent flown yet, to zero
       coalesce(sum(c.char_hours_flown),0) as "Total Hours Flown",
-- Case has been implemented to show the tier of the manufacturer
       Case when sum(c.char_hours_flown) >30 Then 'Tier I Manufacturer'
            when sum(c.char_hours_flown) > 15 And sum(c.char_hours_flown)<30 Then 'Tier II Manufacturer'
            when sum(c.char_hours_flown) > 0 And sum(c.char_hours_flown)<15 Then 'Tier III Manufacturer'
            Else 'New Manufacturer' END AS "Manufacturer Type",
-- below function calls the top destination from the inline select table s1
/*the coalesce function helps to convert the null values
(when a model manufacturer hasnt flowm any aircrafts to any destination), to not applicable*/
        coalesce(s1.td,'Not Applicable') as "Top Destination(Hours)"
from avia.model m full outer join avia.aircraft a
on m.mod_code=a.mod_code
full outer join  avia.charter c
on c.ac_number= a.ac_number 
full outer join 
-- below inline select helps to get the top destination in terms of hours
(
select m.mod_manufacturer,c.char_destination as td, (Sum(char_hours_flown+char_hours_wait))
from avia.model m, avia.aircraft a, avia.charter c
where m.mod_code=a.mod_code 
and a.ac_number=c.ac_number 
group by m.mod_manufacturer, c.char_destination
Having (m.mod_manufacturer, Sum(char_hours_flown+char_hours_wait)) in
(
-- below helps to filter the manufacturer with highest hour flown
select mfl.mod_manufacturer, max(th) from (
-- Below query gives us the destinations for the monufacturers and total hours flown and waited on those destination
select m.mod_manufacturer,c.char_destination as td, (Sum(char_hours_flown+char_hours_wait)) th
from avia.model m, avia.aircraft a, avia.charter c
where m.mod_code=a.mod_code 
and a.ac_number=c.ac_number 
group by m.mod_manufacturer, c.char_destination) mfl
group by mfl.mod_manufacturer)
) s1
on s1.mod_manufacturer=m.mod_manufacturer
group by m.mod_manufacturer, coalesce(s1.td,'Not Applicable')) q1
 left join
 /*The s2 query helps us o give the destination rank and uses partition by to 
 divide the rankings among different manufacturers*/
(Select m.mod_manufacturer,c.char_destination,count(c.char_trip),
       rank() Over (partition by m.mod_manufacturer order by count(c.char_trip)desc,0) as ranking
    from avia.model m, avia.aircraft a, avia.charter c
    where m.mod_code=a.mod_code
    and a.ac_number =c.ac_number(+)
    group by m.mod_manufacturer,c.char_destination) s2
/*Below are the criteria through which the s2 table has been joined 
with the previous table that gave us the rest of the values*/
on s2.mod_manufacturer = q1."Manufacturer Name"
and s2.char_destination = q1."Top Destination(Hours)"
;

--Question 5
/* By submitting this assignment for grading, I state or affirm that the work submitted is my own work and 
I did not receive assistance nor provide assistance from another student (or external agent). */ 
--The query uses hierarchial function to get the referrals 
--Nvl function has been used to display not referred if a customer has not been referred
select tc.cid as "Customer Id",
    tc .cname as "customer Name",
    nvl(rp.rfp, 'Not Referred') as "Referred by"
From 
-- Below select creates a table tc gives us customer id and name
--Piping line helps us to give full customer name 
-- Not in function helps to filter oit the customers that have not purchased any tickets
(select c.cus_code as cid,
       c.cus_Fname||' '||c.Cus_initial||' '||c.cus_Lname as CName
from avia.customer c 
where c.cus_code Not in
(select c1.cus_code
from avia.customer c1, avia.charter ch
where c1.Cus_code=ch.cus_code))tc,
/*Below select gives us the referral path in table rp by using sys_connect_by_path 
and uses connect by prior by connecting the ref_code to cus_code*/
(select r2.cus_code as cc,
Sys_connect_by_path(c2.cus_lname, '/') as rfp
from avia.referral r2, avia.customer c2
where r2.ref_code=c2.cus_code
connect by 
prior r2.cus_code=r2.ref_code
Start with not exists 
/*to filter the results for level 1 path in order to avoid 
duplicate entries in the path*/
(Select 1 from avia.referral r3
where r3.cus_code=r2.ref_code)) rp
where tc.cid = rp.cc
;

--Question 6
/* By submitting this assignment for grading, I state or affirm that the work submitted is my own work and 
I did not receive assistance nor provide assistance from another student (or external agent). */ 
--The query uses pivot function to achieve desired result in terms of avergae wait hour
--All the coalesce function helps to convert the null values into 0
select a.AC_Number as "Aircraft Number",
       m.mod_manufacturer||' '||m.mod_name as "Model",
        coalesce(aw."Avg Wait-MQY", 0) as "Avg Wait-MQY",
        coalesce(aw."Avg Wait-BNA",0)as "Avg Wait-BNA",
        coalesce(aw."Avg Wait-GNV",0)as "Avg Wait-GNV",
        coalesce(aw."Avg Wait-MOB",0)as "Avg Wait-MOB",
        coalesce(aw."Avg Wait- STL",0)as "Avg Wait-STL",
        coalesce(aw."Avg Wait-ATL",0)as "Avg Wait-ATL",
        coalesce(aw."Avg Wait-TYS",0)as "Avg Wait-TYS",
        total.thf as "Total Hours Flown",
        total.tdt as "Total Distance Travelled"
from avia.model m, avia.aircraft a,
(
select *
from 
/*Below demonstrates the use of pivot to flip the row values for wait time into 
the column values after the use of an aggregate average function*/
(select AC_Number, Char_destination , Char_Hours_Wait
 From avia.charter) 
Pivot
(Avg(Char_Hours_Wait) 
for Char_destination In 
        ('MQY' as "Avg Wait-MQY",
         'BNA' as "Avg Wait-BNA",
        'GNV' as "Avg Wait-GNV",
        'MOB' as "Avg Wait-MOB",
        'STL' as "Avg Wait- STL",
        'ATL' as "Avg Wait-ATL",
        'TYS' as "Avg Wait-TYS") 
        )) aw,
/*Below inline select(total table) helps to get the total distance travelled and total hours 
flown for the particular model and aircraft number*/
(select ac_number,sum(char_hours_flown)as thf,
        sum(char_distance) as tdt
from avia.charter
group by ac_number) total
where m.mod_code =a.mod_code
and a.ac_number=aw.ac_number
and total.ac_number =a.ac_number
and coalesce(aw."Avg Wait-ATL",0) =0
--Order by to sort the results in the required sequence
order by "Model","Total Hours Flown" desc, "Total Distance Travelled" desc
;

--Question 7
/* By submitting this assignment for grading, I state or affirm that the work submitted is my own work and 
I did not receive assistance nor provide assistance from another student (or external agent). */ 
--We have used 5 inline slects to get the respective condition
--Employees with no ratings have been given a low number of ratings using nvl function
--The employees with no ratings come up as No ratings in the list using NVL function
select e.emp_num as "Employee Number",
    nvl(ert.empr,'Low') as "Number of Ratings",
    nvl(ert1.a, 'No Ratings') as "Employee Ratings",
    nvl(ert2.empr1, 'Low') as "Number of Ratings Since 2005",
    nvl(ert3.a1,'No Ratings') as"Employee Ratings Since 2005",
    nvl(ert3.rank, '0') as "Rating Rank"
from avia.employee e,
--below slect givs us the number of ratings. 
--A case function has been used to get the high, low , medium
(select e.emp_num, count(er.rtg_code),
    case when count(er.rtg_code)>=5 Then 'High'
         when count(er.rtg_code)>=3 and count(er.rtg_code)<5 Then 'Medium'
    else 'low' end as empr
 from avia.employee e, avia.earnedrating er
 where e.emp_num = er.emp_num
 group by e.emp_num) ert,
 --following slect uses list tag to list all the ratings that the employees have acquired
 (select e1.emp_num, listagg(r.rtg_code, ',') 
    within group (order by r.rtg_code) as a
    from avia.employee e1, avia.earnedrating r
    where e1.emp_num= r.emp_num
    group by e1.emp_num) ert1,
--below slect give us the number of ratings since 2005 
--A case function has been used to get the high, low , medium
(select e.emp_num, count(er.rtg_code),
    case when count(er.rtg_code)>=5 Then 'High'
         when count(er.rtg_code)>=3 and count(er.rtg_code)<5 Then 'Medium'
    else 'low' end as empr1
 from avia.employee e, avia.earnedrating er
 where e.emp_num = er.emp_num
 and er.earnrtg_date>'01-Jan-2005'
 group by e.emp_num) ert2,
 --following slect uses list tag to list all the ratings that the employees have acquired since 2005
 (select e1.emp_num, listagg(r.rtg_code, ',') 
    within group (order by r.rtg_code) as a1,
    dense_rank() over (order by count(rtg_code)desc) as rank
    from avia.employee e1, avia.earnedrating r
    where e1.emp_num= r.emp_num
    and r.earnrtg_date>'01-Jan-2005'
    group by e1.emp_num) ert3
--following outer joins have been used to include all employees irrespctive of them having a rating or not
 where e.emp_num= ert.emp_num(+)
 and e.emp_num=ert1.emp_num(+)
 and ert2.emp_num(+)=e.emp_num
 and ert3.emp_num(+)=e.emp_num
 order by e.emp_num
 ;


        
        

